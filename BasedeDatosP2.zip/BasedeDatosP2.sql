-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               11.4.5-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.10.0.7000
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table proh.categorias
CREATE TABLE IF NOT EXISTS `categorias` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table proh.categorias: ~0 rows (approximately)

-- Dumping structure for table proh.detalle
CREATE TABLE IF NOT EXISTS `detalle` (
  `codigo_pedido` int(11) NOT NULL,
  `codigo_producto` int(11) NOT NULL,
  `unidades` int(11) DEFAULT 1,
  `precio_unitario` decimal(8,2) DEFAULT 0.00,
  PRIMARY KEY (`codigo_pedido`,`codigo_producto`),
  KEY `contiene` (`codigo_producto`),
  CONSTRAINT `contiene` FOREIGN KEY (`codigo_producto`) REFERENCES `productos` (`codigo`),
  CONSTRAINT `referentea` FOREIGN KEY (`codigo_pedido`) REFERENCES `pedidos` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table proh.detalle: ~39 rows (approximately)
INSERT INTO `detalle` (`codigo_pedido`, `codigo_producto`, `unidades`, `precio_unitario`) VALUES
	(1, 10, 1, 10.00),
	(1, 28, 2, 15.00),
	(1, 29, 1, 10.00),
	(2, 1, 2, 5.00),
	(2, 10, 1, 10.00),
	(2, 28, 2, 15.00),
	(2, 29, 2, 10.00),
	(3, 1, 3, 5.00),
	(3, 2, 1, 15.00),
	(4, 1, 3, 5.00),
	(4, 2, 1, 15.00),
	(5, 1, 1, 5.00),
	(5, 2, 1, 15.00),
	(6, 1, 3, 5.00),
	(7, 1, 3, 5.00),
	(8, 1, 3, 5.00),
	(9, 2, 1, 15.00),
	(10, 1, 1, 5.00),
	(10, 2, 1, 15.00),
	(11, 1, 1, 5.00),
	(11, 2, 1, 15.00),
	(12, 2, 1, 15.00),
	(13, 3, 1, 10.00),
	(14, 3, 1, 10.00),
	(15, 1, 1, 5.00),
	(16, 1, 1, 5.00),
	(17, 2, 1, 15.00),
	(18, 1, 1, 5.00),
	(19, 1, 1, 5.00),
	(20, 1, 3, 5.00),
	(21, 2, 1, 15.00),
	(21, 29, 1, 10.00),
	(21, 38, 1, 20.00),
	(22, 2, 1, 15.00),
	(22, 29, 1, 10.00),
	(22, 38, 1, 20.00),
	(23, 2, 1, 15.00),
	(23, 29, 1, 10.00),
	(23, 38, 1, 20.00);

-- Dumping structure for table proh.estados
CREATE TABLE IF NOT EXISTS `estados` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table proh.estados: ~4 rows (approximately)
INSERT INTO `estados` (`codigo`, `descripcion`) VALUES
	(1, 'Pendiente'),
	(2, 'Enviado'),
	(3, 'Entregado'),
	(4, 'Cancelado');

-- Dumping structure for table proh.pedidos
CREATE TABLE IF NOT EXISTS `pedidos` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `persona` int(11) NOT NULL,
  `fecha` date DEFAULT curdate(),
  `importe` decimal(8,2) DEFAULT 0.00,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `pedidopor` (`persona`),
  KEY `enestado` (`estado`),
  CONSTRAINT `enestado` FOREIGN KEY (`estado`) REFERENCES `estados` (`codigo`),
  CONSTRAINT `pedidopor` FOREIGN KEY (`persona`) REFERENCES `usuarios` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table proh.pedidos: ~23 rows (approximately)
INSERT INTO `pedidos` (`codigo`, `persona`, `fecha`, `importe`, `estado`) VALUES
	(1, 1, '2025-05-04', 50.00, 4),
	(2, 1, '2025-05-04', 70.00, 4),
	(3, 1, '2025-05-04', 30.00, 4),
	(4, 1, '2025-05-04', 30.00, 4),
	(5, 1, '2025-05-04', 20.00, 4),
	(6, 1, '2025-05-04', 15.00, 4),
	(7, 1, '2025-05-04', 15.00, 1),
	(8, 1, '2025-05-04', 15.00, 1),
	(9, 1, '2025-05-04', 15.00, 1),
	(10, 1, '2025-05-04', 20.00, 1),
	(11, 1, '2025-05-04', 20.00, 4),
	(12, 1, '2025-05-04', 15.00, 1),
	(13, 1, '2025-05-04', 10.00, 1),
	(14, 1, '2025-05-04', 10.00, 1),
	(15, 1, '2025-05-04', 5.00, 1),
	(16, 8, '2025-05-04', 5.00, 4),
	(17, 1, '2025-05-04', 15.00, 1),
	(18, 1, '2025-05-04', 5.00, 1),
	(19, 1, '2025-05-05', 5.00, 1),
	(20, 8, '2025-05-08', 15.00, 4),
	(21, 9, '2025-05-08', 45.00, 4),
	(22, 9, '2025-05-08', 45.00, 4),
	(23, 9, '2025-05-08', 45.00, 4);

-- Dumping structure for table proh.productos
CREATE TABLE IF NOT EXISTS `productos` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) DEFAULT NULL,
  `precio` decimal(8,2) DEFAULT 0.00,
  `existencias` int(11) DEFAULT 0,
  `imagen` varchar(255) DEFAULT NULL,
  `categoria` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table proh.productos: ~45 rows (approximately)
INSERT INTO `productos` (`codigo`, `descripcion`, `precio`, `existencias`, `imagen`, `categoria`) VALUES
	(1, 'Banano', 5.00, 3, 'img/Banano.png', 1),
	(2, 'Mimo', 15.00, 10, 'img/Mimo.png', 1),
	(3, 'Holograma', 10.00, 10, 'img/Holograma.png', 1),
	(4, 'Cavendish', 50.00, 5, 'img/Cavendish.png', 1),
	(5, 'ADN', 20.00, 5, 'img/ADN.png', 1),
	(6, 'Comodín de piedra', 15.00, 10, 'img/ComodinPiedra.png', 1),
	(7, 'Ramen', 15.00, 10, 'img/Ramen.png', 1),
	(8, 'Punta de flecha', 15.00, 10, 'img/PuntaDeFlecha.png', 1),
	(9, 'Papel Perforado', 10.00, 10, 'img/PapelPerforado.png', 1),
	(10, 'Excedente de Renovaciones', 10.00, 10, 'img/renovaciones.png', 2),
	(11, 'Excedente', 10.00, 10, 'img/excedente.png', 2),
	(12, 'Bola de Cristal', 10.00, 10, 'img/bolacristal.png', 2),
	(13, 'Telescopio', 10.00, 10, 'img/telescopio.png', 2),
	(14, 'Acaparador', 10.00, 10, 'img/acaparador.png', 2),
	(15, 'Derrochador', 10.00, 10, 'img/derrochador.png', 2),
	(16, 'Observatorio', 20.00, 5, 'img/observatorio.png', 2),
	(17, 'Pinza para nachos', 20.00, 5, 'img/nachos.png', 2),
	(18, 'Reciclomania', 100.00, 5, 'img/reciclomania.png', 2),
	(19, 'El loco', 15.00, 10, 'img/loco.png', 3),
	(20, 'El mago', 15.00, 10, 'img/ElMago.png', 3),
	(21, 'La sacerdotisa', 15.00, 10, 'img/sacerdote.png', 3),
	(22, 'La emperatriz', 15.00, 10, 'img/emperatriz.png', 3),
	(23, 'El emperador', 20.00, 10, 'img/emperador.png', 3),
	(24, 'Los enamorados', 15.00, 10, 'img/enamorados.png', 3),
	(25, 'El carro', 15.00, 10, 'img/carro.png', 3),
	(26, 'La justicia', 15.00, 10, 'img/justicia.png', 3),
	(27, 'La rueda', 15.00, 10, 'img/rueda.png', 3),
	(28, 'Mercurio', 15.00, 10, 'img/mercurio.png', 4),
	(29, 'Venus', 10.00, 10, 'img/venus.png', 4),
	(30, 'Tierra', 15.00, 10, 'img/tierra.png', 4),
	(31, 'Marte', 20.00, 10, 'img/marte.png', 4),
	(32, 'Jupiter', 25.00, 10, 'img/jupiter.png', 4),
	(33, 'Saturno', 30.00, 10, 'img/saturno.png', 4),
	(34, 'Urano', 15.00, 10, 'img/urano.png', 4),
	(35, 'Neptuno', 50.00, 10, 'img/neptuno.png', 4),
	(36, 'Pluto', 5.00, 10, 'img/pluto.png', 4),
	(37, 'Sigilo', 25.00, 10, 'img/sigilo.png', 5),
	(38, 'Familiar', 20.00, 10, 'img/familiar.png', 5),
	(39, 'Ectoplasma', 30.00, 10, 'img/ectoplasma.png', 5),
	(40, 'Aura', 25.00, 10, 'img/aura.png', 5),
	(41, 'Encantamiento', 20.00, 10, 'img/encantamiento.png', 5),
	(42, 'Críptido', 15.00, 10, 'img/criptido.png', 5),
	(43, 'Trance', 20.00, 10, 'img/trance.png', 5),
	(44, 'Alma', 100.00, 10, 'img/alma.png', 5),
	(45, 'Agujero Negro', 50.00, 10, 'img/anegro.png', 5);

-- Dumping structure for table proh.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(32) NOT NULL,
  `clave` varchar(40) DEFAULT '',
  `activo` int(11) DEFAULT 1,
  `admin` int(11) DEFAULT 0,
  `nombre` varchar(64) DEFAULT NULL,
  `apellidos` varchar(128) DEFAULT NULL,
  `domicilio` varchar(128) DEFAULT NULL,
  `poblacion` varchar(64) DEFAULT NULL,
  `provincia` varchar(32) DEFAULT NULL,
  `cp` int(11) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table proh.usuarios: ~9 rows (approximately)
INSERT INTO `usuarios` (`codigo`, `usuario`, `clave`, `activo`, `admin`, `nombre`, `apellidos`, `domicilio`, `poblacion`, `provincia`, `cp`, `telefono`) VALUES
	(1, 'deco', '123', 1, 0, 'Andre', 'Magalhaes', 'bomboclat', 'Valencia', 'Valencia', 46920, 640155410),
	(2, 'decoAdmin', '123', 1, 1, 'Andre', 'Magalhaes', 'Calle', 'Valencia', 'Valencia', 46920, 640410410),
	(3, 'decorito', '123', 1, 0, 'oiasoid', 'ohaoisdo', 'hasiodio', 'oahshiod', 'aoiasjdoi', 46920, 641410410),
	(4, 'decorito2', '123', 1, 0, 'aohsdoi', 'oasiodnio', 'niosandionoi', 'noasnodjno', 'oasd', 46920, 641410410),
	(5, 'decorito3', '123', 1, 0, 'Andre', 'Magalhaes', 'jasidj', 'oijaosidjasiod', 'iasiodsa', 46920, 641410410),
	(6, 'deco2', '123', 1, 0, 'Andre', 'Magalhaes', 'Calle', 'valencia', 'Valencia', 46920, 641410410),
	(7, 'deco3', '123', 1, 0, 'oansoid', 'oiasndio', 'nioasndion', 'oiansiodn', 'oinasiod', 46920, 641410410),
	(8, 'rafael', '123', 1, 0, 'aosdoi', 'ojiashjdio', 'jhioasjhdioj', 'iosodjoi', 'jasdiojo', 46920, 592120120),
	(9, 'lunita', '123', 1, 0, 'zorra', 'puta', 'balatreo', 'balatra', 'balileo', 46920, 640155155);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
